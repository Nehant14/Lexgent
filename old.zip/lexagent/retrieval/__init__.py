"""Retrieval utilities for LexAgent."""
